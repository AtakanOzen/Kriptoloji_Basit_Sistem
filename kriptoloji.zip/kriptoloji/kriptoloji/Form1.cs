﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kriptoloji
{
    public partial class Form1 : Form
    {
        
        string turkAlfabesi = "ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVXYZ";  //istediğimiz harf veya sembolü ekleyebiliriz

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }
       

        public Form1()
        {
            InitializeComponent();
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
           
            string input = textBox1.Text.ToUpper().Replace(" ", "");

            string permuted = PermutasyonSifrele(input);
           
            string kaydirmali = KaydirmaSifreleme(permuted);


            textBox2.Text = kaydirmali;
            textBox3.Text = kaydirmali;
        }

       
        private void button2_Click(object sender, EventArgs e)
        {
            
            string kaydirmali = textBox3.Text.ToUpper();
           
            string permuted = KaydirmaCoz(kaydirmali);
            
            string original = PermutasyonCoz(permuted);

           
            textBox4.Text = original.TrimEnd('X'); // Dolgu harflerini siler
        }

        
        private string PermutasyonSifrele(string metin)
        {
            int blokBoyu = 3;  
            string sonuc = "";
            
            while (metin.Length % blokBoyu != 0)
                metin += "X";
          
            for (int i = 0; i < metin.Length; i += blokBoyu)
            {
                string blok = metin.Substring(i, blokBoyu);
               
                string yeniBlok = "" + blok[2] + blok[0] + blok[1];
                sonuc += yeniBlok;
            }

            return sonuc;
        }

    
        private string KaydirmaSifreleme(string metin)
        {
            string sonuc = "";
          
            for (int i = 0; i < metin.Length; i++)
            {
                char harf = metin[i];
                int index = turkAlfabesi.IndexOf(harf);
                
                if (index == -1)
                {
                    sonuc += harf;
                    continue;
                }

                int kaydir = (i % 2 == 0) ? 2 : 1;  // Çift index için +2, tek index için +1
                int yeniIndex = (index + kaydir) % turkAlfabesi.Length;
                sonuc += turkAlfabesi[yeniIndex];
            }

            return sonuc;
        }

      
        private string KaydirmaCoz(string metin)
        {
            string sonuc = "";
           
            for (int i = 0; i < metin.Length; i++)
            {
                char harf = metin[i];
                int index = turkAlfabesi.IndexOf(harf);
               
                // Geçersiz karakteri atla
                if (index == -1)
                {
                    sonuc += harf;
                    continue;
                }

                int kaydir = (i % 2 == 0) ? 2 : 1;  // Çift index için +2, tek index için +1
                int yeniIndex = (index - kaydir + turkAlfabesi.Length) % turkAlfabesi.Length;
                sonuc += turkAlfabesi[yeniIndex];
            }

            return sonuc;
        }

 
        private string PermutasyonCoz(string metin)
        {
            int blokBoyu = 3;
            string sonuc = "";

            for (int i = 0; i < metin.Length; i += blokBoyu)
            {
                string blok = metin.Substring(i, blokBoyu);
             
                string cozulmus = "" + blok[1] + blok[2] + blok[0];
                sonuc += cozulmus;
            }

            return sonuc;
        }



        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }
    }
}